#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct info{
    int codigo;
    char desc[50];
    float valor;
    int quantidade;
};

void bubble_sort(struct info vet[]){
    struct info aux;
    for(int i=0;i<10;i++){
        for(int j=0;j<9;j++){
            if(vet[j+1].codigo<vet[j].codigo){
                aux = vet[j+1];
                vet[j+1]=vet[j];
                vet[j]=aux;
            }
        }
    }
}

int main()
{
    struct info produtos[10];
    printf("Digite as informacoes dos produtos na seguinte ordem:\nCodigo\nValor\nQuantidade\nDescricao\n");
    for(int i=0;i<10;i++){
        scanf("%d",&produtos[i].codigo);
        scanf("%f",&produtos[i].valor);
        scanf("%d",&produtos[i].quantidade);
        scanf("%s",&produtos[i].desc);
    }
    bubble_sort(produtos);
    return 0;
}