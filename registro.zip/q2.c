#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct ordem_servico{
    int os;
    char data[11];
    float valor;
    char desc[50];
    char nome[50];
};
void media_valores(struct ordem_servico vet[],int n)
{
    float soma=0;
    for(int i=0;i<n;i++){
        soma+=vet[i].valor;
    }
    printf("\nA media dos valores de servico: %.2f",(soma/n));
}
void servico_caro(struct ordem_servico vet[],int n)
{
    int maior=0,x;
    for(int i=0;i<n;i++){
        if(vet[i].valor>maior){
            maior=vet[i].valor;
            x=i;
        }
    }
    printf("\nO nome do cliente com o servico mais caro: %sA descricao desse servico: %sA data desse servico: %s",vet[x].nome,vet[x].desc,vet[x].data);
}
int main()
{
    int n;
    printf("Digite a quantidade de clientes:");
    scanf("%d",&n);
    struct ordem_servico clientes[n];
    printf("Insira os dados de cada OS de acordo com a seguinte ordem:\nData\nDescricao\nNome do cliente\nValor\n");
    for(int i=0;i<n;i++){
        printf("Digite as informacoes da ordem de servico %d\n",(i+1));
        scanf("%s",&clientes[i].data);
        fflush(stdin);
        
        fgets(clientes[i].desc,50,stdin);
        fgets(clientes[i].nome,50,stdin);
        
        scanf("%f",&clientes[i].valor);
    }
    media_valores(clientes,n);
    servico_caro(clientes,n);
    return 0;
}