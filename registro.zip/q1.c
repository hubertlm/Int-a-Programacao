#include<stdio.h>
#include<string.h>
struct pesquisa{
    float salario;
    int idade;
    int filho;
    char sexo[2];
};
void media_salario(struct pesquisa populacao[])
{
    float soma=0;
    for(int i=0;i<20;i++)
    {
        soma+=populacao[i].salario;
    }
    printf("\nA media de salario da populacao eh: %.2f",(soma/20));
}
void media_filho(struct pesquisa populacao[])
{
    float soma=0;
    for(int i=0;i<20;i++)
    {
        soma+=populacao[i].filho;
    }
    printf("\nA media de filhos da populacao eh: %.2f",(soma/20));
}
void maior_salario(struct pesquisa populacao[])
{
    float maior=0;
    for(int i=0;i<20;i++)
    {
        if(populacao[i].salario>maior)
            maior=populacao[i].salario;
    }
    printf("\nO maior de salario da populacao eh: %.2f",(maior));
}
void percentual_mulheres(struct pesquisa populacao[])
{
    float percentual;
    int count=0;
    for(int i=0;i<20;i++)
    {
        if(strcmp(populacao[i].sexo,"F")==0){
            if(populacao[i].salario>=10000){
                count++;
            }
        }
    }
    percentual=(count/20.0)*100;
    printf("\nO percentual de mulheres com salario superior a 10000: %.2f",percentual);
}
int main()
{
   struct pesquisa populacao[20];
   printf("Insira as informacoes de cada pessoa na seguinte ordem:\nSalario\nIdade\nQuantidade de filhos\nSexo\n");
   for(int i=0;i<20;i++)
   {
        scanf("%f",&populacao[i].salario);
        scanf("%d",&populacao[i].idade);
        scanf("%d",&populacao[i].filho);
        scanf("%s",&populacao[i].sexo);
   }
    media_salario(populacao);
    media_filho(populacao);
    maior_salario(populacao);
    percentual_mulheres(populacao);
    return 0;
}