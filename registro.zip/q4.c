#include<stdio.h>
#include<string.h>
#include<stdlib.h>
//Este programa estabelece 30 dias para todos os meses do ano e 365 dias para cada ano
struct conta{
    int documento;
    int codigo;
    int dv_dia;
    int dv_mes;
    int dv_ano;
    int dp_dia;
    int dp_mes;
    int dp_ano;
    float valor_conta;
};
int calcula_juros(struct conta vet[],int i){
    int dias_p,dias_v,aux;
    float juros;
        dias_p=(vet[i].dp_ano*365)+(vet[i].dp_mes*30)+(vet[i].dp_dia);
        dias_v=(vet[i].dv_ano*365)+(vet[i].dv_mes*30)+(vet[i].dv_dia);
        if(dias_p>dias_v)
            aux = dias_p-dias_v;
        else
            aux = 0;
        juros = ((0.02*vet[i].valor_conta)*aux)/100;
        return juros;
    }
    int main()
    {
        struct conta clientes[2];
        float soma=0;
        printf("Digite as informacoes de cada conta de acordo com a seguinte ordem:\nDocumento\nCodigo\nData de vencimento\nData de pagamento\nValor da conta\n");
        for(int i=0;i<2;i++){
            scanf("%d",&clientes[i].documento);
            scanf("%d",&clientes[i].codigo);
            printf("\nDigite a data de vencimento do boleto digitando dia, mes e ano pressionando a tecla enter: ");
            scanf("%d",&clientes[i].dv_dia);
            
            scanf("%d",&clientes[i].dv_mes);
            
            scanf("%d",&clientes[i].dv_ano);
            printf("\nDigite a data de pagamento do boleto digitando dia, mes e ano pressionando a tecla enter: ");
            scanf("%d",&clientes[i].dp_dia);
            
            scanf("%d",&clientes[i].dp_mes);
            
            scanf("%d",&clientes[i].dp_ano);
            scanf("%f",&clientes[i].valor_conta);                
        }
        for(int i=0;i<2;i++)
        {
            soma+=(calcula_juros(clientes,i));
        }
        printf("O total arrecadado com juros foi: %.2f",soma);
        return 0;
    }