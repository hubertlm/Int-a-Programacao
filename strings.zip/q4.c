#include<stdio.h>
#include<string.h>
#include<conio.h>
    void bubble_sort(char v[])
    {
        char aux;
        int n=strlen(v);
        for(int i=0;i<(n-1);i++)
            {
                for(int j=0;j<(n-2);j++)
                {
                    if(v[j+1]>v[j])
                    {
                        aux = v[j];
                        v[j]=v[j+1];
                        v[j+1]=aux;
                    }
                }
            }
    }
    int main()
    {
        char p1[50],p2[50];
        printf("Digite a primeira palavra: ");
        gets(p1);
        printf("Digite a segunda palavra: ");
        gets(p2);
        bubble_sort(p1);
        bubble_sort(p2);
        int teste = strcmp(p1,p2);
        if(teste==0)
            printf("Uma palavra eh anagrama da outra!");
        else
            printf("Uma palavra nao eh anagrama da outra!");
        return 0;
    }