#include<stdio.h>
#include<string.h>
#include<conio.h>

    void pref(char palavra[])
    {
        int n=strlen(palavra);
        for(int i=0;i<n;i++)
        {
            for(int j=i;j<n;j++)
            {
               printf("%c",palavra[j]);
            }
            printf("\n");
        }
    }
    int main()
    {
        char palavra[50];
        printf("Digite uma palavra: ");
        gets(palavra);
        printf("Os sufixos da palavra %s, sao:\n",palavra);
        pref(palavra);
        return 0;
    }