#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <conio.h>

    void verifica(char email[])
    {
        int n=strlen(email),count=0,verificador=0,aux;
        for(int i=0;i<(n-1);i++)
        {
            if(email[i]=='@')
                count++;
        }
        if(count==1)
        {
           char*p = strchr(email,'@');
           int index = p-email;
           for(int i=0;i<index;i++)
           {
                aux=email[i];
                if(aux>=65&&aux<=90)
                    verificador=1;    
           }
           count=0;
           for(int i=index;i<(n-1);i++)
           {
                if(email[i]=='.'){
                    if(email[i]==email[i-1])
                        verificador=1;
                    else
                        count++;
                }
                    
           }
           if(count==0||count>2)
                verificador=1;
        }
        else
            verificador=1;
        if(verificador==0)
            printf("Email valido!");
        else if(verificador==1)
            printf("Email invalido!");    
        }
    
    int main()
    {
        char email[100];
        printf("Digite o seu email: ");
        gets(email);
        verifica(email);
        return 0;
    }