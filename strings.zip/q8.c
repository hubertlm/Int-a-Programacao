#include<stdio.h>
#include<string.h>
#include<conio.h>
    void remover(char frase[])
    {
        char aux;
        for(int i=0;i<strlen(frase)-1;i++)
        {
            if(frase[i]==' ')
            {
                aux=frase[i+1];
                frase[i+1]=frase[i];
                frase[i]=aux;
            }
        }
    }
    void subcadeias(char frase[],int n)
    {
        int x=strlen(frase)-1,y;
        if(x%n==0)
            y=x/n;
        else
            y=(x/n)+1;

        int aux=0;
        for(int i=1;i<=y;i++)
        {
            for(int j=aux;j<(n*i);j++)
            {
                    if(frase[i]!=0)
                        printf("%c",frase[j]);
            }
            printf("\n");
            aux+=n;
        }
    }
    
    
    int main()
    {
        char frase[50];
        int n;        
        printf("Insira a cadeia de caracteres: ");
        gets(frase);
        printf("Digite um numero n: ");
        scanf("%d",&n);
        printf("A frase digitada dividida em subcadeias de tamanho %d: ",n);
        remover(frase);
        subcadeias(frase,n);
        return 0;
    }
