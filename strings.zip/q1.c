#include<stdio.h>
#include<string.h>
#include<conio.h>

int main()
{
    char frase[100];
    int aux=0;
    printf("Digite uma frase: ");
    gets(frase);
    int x=strlen(frase);
    for(int i=0;i<x;i++)
    {
        aux=frase[i];
        if(aux>=65&&aux<=90)
            frase[i]=tolower(frase[i]);
        else
            frase[i]=toupper(frase[i]);
    }
    printf("A frase alterada: %s",frase);
    return 0;
}