#include<stdio.h>
#include<string.h>
#include<conio.h>

    int main()
    {
        char palavra[50],x;
        printf("Digite uma frase:");
        gets(palavra);
        printf("Digite o caracter que deseja retirar dessa frase: ");
        scanf("%c",&x);
        char palavra_nova[50];
        int j=0;
        for(int i=0;i<strlen(palavra);i++)
        {
            if(palavra[i]!=x)
                {
                palavra_nova[j]=palavra[i];
                j++;
                }
        }
        palavra_nova[j]='\0';
        printf("A frase sem o caracter %c: %s",x,palavra_nova);
        return 0;
    }