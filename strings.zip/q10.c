#include <stdio.h>
#include <string.h>
#include <conio.h>
char alfa_A[27]="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
char alfa_a[27]="abcdefghijklmnopqrstuvwxyz";
char especial[32]=" !#$%&'()*+,-./:;<=>?@[\]^_`{|}~";
char num[11]="0123456789";
int verifica(char senha[])
{
    int cont1=0,cont2=0,cont3=0,cont4=0,x=0;
    for(int i=0;i<(strlen(senha)-1);i++)
    {
        for(int j=0;j<26;j++)
        {
            if(senha[i]==alfa_A[j]){
                cont1++;
        }
        }
        for(int j=0;j<26;j++)
        {
            if(senha[i]==alfa_a[j]){
                cont2++;
        }
        }
        for(int j=0;j<31;j++)
        {
            if(senha[i]==especial[j]){
                cont3++;
        }
        }
        for(int j=0;j<10;j++)
        {
            if(senha[i]==num[j]){
                cont4++;
        }
        }
    }
    if(cont1>=1&&cont2>=1&&cont3>=1&&cont4>=1)
        x=1;

    return x;
}

int main()
{
    char senha[15];
    printf("Digite sua senha: ");
    gets(senha);
    if(strlen(senha)<8){
        printf("Senha invalida!");
        return 0;}
    else{
    int x = verifica(senha);
    if(x==1)
        printf("Senha valida!");
    else
        printf("Senha invalida!");
    }
    return 0;
}