#include<stdio.h>
#include<string.h>
#include<conio.h>
int main()
{
    char nome_completo[50];
    printf("Digite seu nome completo:");
    gets(nome_completo);
    char *pos;
    pos=strrchr(nome_completo,' ');
    int index=pos-nome_completo;
    char p1[(strlen(nome_completo)-index)];
    int j=0;
    for(int i=(index+1);i<strlen(nome_completo);i++)
    {
        p1[j]=nome_completo[i];
        j++;
    }
    p1[(strlen(nome_completo)-index)]='\0';
    nome_completo[(index+1)]='\0';
    printf("%s, %s",p1,nome_completo);
    return 0;
}