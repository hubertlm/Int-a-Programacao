#include<stdio.h>

int fatorial(int n)
{
    if(n<=1)
        return n;
    else{
        int x= fatorial(n-1)*n;
        return x;
    }
}
float somatorio(int n)
{
    float S=1;
    for(int i=1;i<=n;i++)
    {
        S+=1.0/fatorial(i);
    }
    return S;
}
int main()
{
    int n=5;
    printf("%.2f",somatorio(n));
    return 0;
}