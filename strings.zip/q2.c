#include<stdio.h>
#include<string.h>
#include<conio.h>

int palindromo(char palavra[])
{
    char aux[50];
    int x=strlen(palavra),n=strlen(palavra);
    for(int i=0;i<n;i++)
    {
        aux[i]=palavra[x-1];
        x--;
    }
    palavra[n]='\0';
    int teste=strcmp(palavra,aux);
    return teste;
}
int main()
{
    char palavra[50];
    printf("Digite uma palavra para verfificar se elea eh um palindromo ou nao: ");
    gets(palavra);
    int teste=palindromo(palavra);
    if(teste==0)
        printf("A palavra %s eh um palindromo",palavra);
    else    
        printf("A palavra %s nao eh um palindromo",palavra);
    return 0;
}