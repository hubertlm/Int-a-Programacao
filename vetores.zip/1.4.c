#include<stdio.h>
int main()
{
    float x[10];
    float alt,med,soma;
    soma=0;
    printf("DIgite a altura dos 10 atletas, um a um, pressioando a tecla enter: ");
    for(int i=0;i<10;i++)
    {
        scanf("%f",&alt);
        x[i]=alt;
        soma+=alt;
    }
    med=soma/10;
    int y=0;
    printf("Os atletas com altura maior que a media(%.2f) tem as seguintes alturas: ",med);
    while(y<10)
    {
        if(x[y]>med)
        {
            printf("\n%.2f",x[y]);
        }
        y++;
        
    }
    return 0;
}