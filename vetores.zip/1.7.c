#include<stdio.h>
int main()
{
    float temp[121];
    float n,maior,menor,med,soma;
    int cont=0;
    soma=0;
    maior=0;
    menor=0;
    printf("Inisira a temperatura desses dias, um a um, pressionando a tecla enter: ");
    for(int i=0;i<121;i++)
    {
        scanf("%f",&n);      
        if(n<15||n>40)
        {
        printf("Temperatura invalida");
        return 0;
        }
        else
        {
            n=temp[i];
            soma+=temp[i];
        }
    }
    for(int i=0;i<121;i++)
    {
        if(temp[i]>maior)
        {
            maior=temp[i];
        }
        if(temp[i]<menor)
        {
            menor=temp[i];
        }
    }
    med=soma/121;
    for(int i=0;i<121;i++)
    {
        if(temp[i]<med)
            cont++;
    }
    printf("A menor temperatura ocorrida foi de %.2fºC",menor);
    printf("\nA maior temperatura resgistrada foi de %.2fºC",maior);
    printf("\nA media das temperaturas nesse intevalo de tempo foi de %.2fºC",med);
    printf("A quantidade de dias com a temperatura abaixo da media foi de %d",cont);

    return 0;
}