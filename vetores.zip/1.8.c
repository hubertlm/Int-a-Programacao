#include<stdio.h>
int main()
{
    int n, A[n],x,rep;
    printf("Digite um valor n para definir o tamanho da variavel: ");
    scanf("%d",&n);
    printf("Digite os valores dessa variavel: ");
    for(int i=0;i<n;i++)
    {
        scanf("%d",x);
        A[i]=x;
    }
    


    return 0;
}