#include<stdio.h>
int main()
{
    int i=200;
    int x[i];
    int y=0;
    for(int i=200;i>=100;i--)
    {
        x[i]=i;
        
    }
   while(y<=i)
   {
    printf("\n%d",x[i]);
    i--;
    y++;
   }

    return 0;
}