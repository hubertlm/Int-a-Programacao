#include<stdio.h>
int main()
{
   
    int x[10];
    int y=0;
    for(int i=1;i<=20;i++)
    {
        if(i%2!=0)
          {
            x[y]=i*i;
            y++;
          }
    }
    y=0;
    while(y<10)
    {
        printf("\n%d",x[y]);
        y++;
       
    }
    return 0;
}