#include<stdio.h>
int main()
{
    long long int x[50];
    long long int fib;
    x[0]=1;
    x[1]=1;
    for(int i=2;i<50;i++)
    {
        fib=x[i-1]+x[i-2];
        x[i]=fib;
       
    }
    int y=0;
    while(y<50)
    {
        printf("\n%lld",x[y]);
        y++;
    }

    return 0;
}