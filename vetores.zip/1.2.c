#include<stdio.h>
int main()
{
     
    int N[100];
    int x=5;
   
    
    for(int i=0;i<100;i++)
    {
            N[i]=x;
            x+=5; 
    }
    x=0;
    while(x<100)
    {
        printf("\n%d",N[x]);
        x++;
    }
    

    return 0;
}