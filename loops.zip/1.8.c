#include<stdio.h>
#include<math.h>
//A disciplina tem 13 semanas e 2 problemas por semana, logo temos 26 problemas ao total(valor que aparece no for)
//Como o aluno começou com um erro no programa e foi dobrando a cada problema seguinte
//Portanto utilizei a potência de 2 como uma maneira de estimar a quantidade de erros por programa
int main()
{
   float x;
   x = 2;
   int erros;
   for(float i=0;i<26;i++)
    {
        erros = pow(x,i);
    }
    printf("O total de erros estimados para o ultimo programa eh de:%d",erros);
    
    return 0;
}