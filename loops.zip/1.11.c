#include<stdio.h>
int main()
{
    int sup,inf,soma_par;
    soma_par = 0;
    printf("Digite o limite inferior do intervalo: ");
    scanf("%d",&inf);
    printf("\nDigite o limete superior do intervalo :");
    scanf("%d",&sup);
    printf("\nOs numeros pares nesse intervalo sao: ");
    for(int i = (inf+1);i < sup;i++)
    {
        if((i % 2)==0)
        {
            soma_par+=i;
            printf(" %d",i);
        }
    }
    printf("\nA soma dos valores pares desse intervalo eh: %d",soma_par);
    return 0;
}