#include<stdio.h>
#include<math.h>
int main()
{
    int a,b,cont,x;
    cont = 0;
    printf("Digite dois numeros inteiros positivos: ");
    scanf("%d %d",&a,&b);
    x = a;
    while ((x)>=b)
   { 
        x = x - b;
        cont++;
   }
    printf("O resto da divisao do primeiro pelo segundo numero resulta em: %d",abs(x));

    return 0;
}