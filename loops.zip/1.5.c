#include<stdio.h>
#include<stdbool.h>
int main()
{
    int n,maior;
    bool continua;
    continua = true;
    maior = 0;
    printf("Escreva N numeros inteiros um a um apertando enter, quando nao desejar digitar mais numeros, insira o numero 0 :");

    while(continua)
    {
        scanf("%d",&n);
        if(n > maior)
        {
            maior = n;
        }
        if(n==0)
        {
            continua = false;
        }

    }

    printf("\nO maior numero digitado foi:%d",maior);

    return 0;
}