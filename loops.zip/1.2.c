#include<stdio.h>
#include<stdbool.h>
int main()
{
    bool continua;
    int n, prod;
    prod = 1;
    continua = true;
    printf("Escreva N numeros inteiros um a um apertando enter, quando nao desejar digitar mais numeros, insira o numero 1 :");

    while(continua)
    {
        scanf("%d",&n);
        prod = prod*n;
        if(n==1)
        continua = false;
    }
    printf("O produto dos numeros digitados eh %d",prod);

    return 0;
}