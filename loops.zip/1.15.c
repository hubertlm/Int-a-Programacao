#include<stdio.h>
int main()
{
    int a,b,cont,x;
    cont = 0;
    x = 1;
    printf("Digite dois numeros inteiros positivos: ");
    scanf("%d %d",&a,&b);

    do
    {
        x *= a;
        cont++;
    } while (cont<b);
    printf("O primeiro numero elevado ao segundo numero resulta em: %d",x);

    return 0;
}