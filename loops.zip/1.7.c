
#include<stdio.h>
//A velocidade relativa de aquiles em relação à tartaruga é de 9m/s, logo utilizamos v=9
int main()
{
int v,s,t;
v = 9;
t = 0;
while((v*t)<=100)
{
    t++;
}
printf("O tempo decorrido foi de %d segundos",t);

return 0;
}