#include<stdio.h>
int main()
{
    int num,d3,d5;
    printf("Digite um numero NUM, que sera o limite superior no intervalo (1,NUM): ");
    scanf("%d",&num);
    printf("Os multiplos de 3 no intervalo (1,num) sao: ");
    for(int i = 1;i < num;i++)
    {
        if((i % 3)==0)
        {
            printf(" %d",i);
        }
    }

     printf("\nOs multiplos de 5 no intervalo (1,num) sao: ");
    for(int j = 1;j < num;j++)
    {
        if((j % 5)==0)
        {
            printf(" %d",j);
        }
    }
    return 0;
}