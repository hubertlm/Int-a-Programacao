#include<stdio.h>
#include<math.h>

int main()
{
    int n;
    float x;
    x = 2;
    printf("insira um numero inteiro N:");
    scanf("%d",&n);
    printf("As N primeiras potencia de 2 sao:");
    for(float i=0;i<n;i++)
     {
        printf("\n%.0f",pow(x,i));
     }

     return 0;
}