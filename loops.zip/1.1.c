#include<stdio.h>
#include<math.h>

int main()
{
   float x;
   x = 2;
   for(float i=0;i<20;i++)
    {
       printf("\n%.0f",pow(x,i));
    }

    return 0;
}