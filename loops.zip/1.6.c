#include<stdio.h>
int main()
{
int n,fat;
printf("Escreva um numero inteiro N: ");
scanf("%d",&n);

for(fat = 1;n > 1;n = n-1 )
{
    fat = fat*n;
}
printf("O fatorial do numero digitado eh: %d",fat);

return 0;
}