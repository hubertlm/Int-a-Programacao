#include<stdio.h>

int main()
{
    int n,soma,med;
    soma = 0;
    printf("Escreva um numero inteiro n: ");
    scanf("%d",&n);
  
    for(int i=0;i<=n;i++)
    {
        soma +=i;
        med = soma/n;    
    }
    printf("A media dos N primeiros numeros inteiros positivos eh:%d",med);

    return 0;
}