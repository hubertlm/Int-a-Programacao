#include<stdio.h>
int main()
{
    int alunos, cont;
    float notas, maior1, maior2, soma, media, x;
    cont = 0;
    soma = 0;
    x = 0;
    printf("DIgite a quantidade de alunos da turma:");
    scanf("%d",&alunos);
    printf("\nDigite as notas dos alunos, uma a uma, pressionando a tecla enter:");
    while(cont < alunos)
    {
        scanf("%f",&notas);
        soma +=notas;
        cont++;
        if(notas > maior1)
        {
            x = notas;
            maior2 = maior1;
            maior1 = x;


        }
        else
        {
            if(notas > maior2){
            maior2 = notas;
            }
        }
    }
    
    media = soma/cont;
    printf("\nAs duas maiores notas da turma foram %.2f e %.2f",maior1,maior2);
    printf("\nA media das notas da turma foi de: %.2f",media);

    return 0;
}