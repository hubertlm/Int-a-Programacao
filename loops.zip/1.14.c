#include<stdio.h>
int main()
{
    int b,cont;
    float a,x;
    printf("Digite um numero real e em seguida,apertando a tecla entar, um numero inteiro: ");
    scanf("%f %d",&a,&b);
    x = 0;
    cont = 0;
    do
    {
        x+=a;
        cont++;
    } while (cont<b);
    printf("O resultado da multiplicacao eh:%.2f",x);
    

    return 0;
}