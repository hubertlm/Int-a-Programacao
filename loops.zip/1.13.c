#include<stdio.h>

int main()
{
int n,cont_par,cont_impar;
cont_par = 0;
cont_impar = 0;
printf("Digite a quantidade de numeros que deseja saber a quantidade de numeros impares e numeros pares: ");
scanf("%d",&n);

for(int i = 1;i <= n;i++)
{
    if((i % 2)==0)
    {
        cont_par++;
    }
    else
    {
        cont_impar++;
    }
}

printf("A quantidade de numeros pares nesse intervalo eh: %d \nA quantidade de numeros impares eh: %d",cont_par,cont_impar);

return 0;
}