#include<stdio.h>
int main()
{
    int n,ze,gal,gil;
    ze = 0;
    gal = 0;
    gil = 0;
printf("Digite 1 para votar no Ze, 2 para votar no Gal e 3 para votar na Gil ");

do
{
    scanf("%d",&n);
    if(n==1)
    ze++;
    if(n==2)
    gal++;
    if(n==3)
    gil++;
} while (n!=0);
if(ze>gal&&ze>gil)
{
    printf("O vencedor da eleicao foi Ze");
}
else if(gal>gil)
{
    printf("O vencedor da eleicao foi Gal");
}
else 
{
    printf("A vencedora da eleicao foi Gil");
}
return 0;
}