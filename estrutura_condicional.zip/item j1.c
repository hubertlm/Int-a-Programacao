#include<stdio.h>
#include<math.h>
int main()
{
    int x;
    printf("Digite um numero:");
    scanf("%d",&x);
    if(x == (x/3)*3)
    {
        printf("%d eh multiplo de 3",x);
        return 0;
    }
    else
    {
        printf("%d nao eh multiplo de 3",x);
        return 0;
    }



    return 0;
}