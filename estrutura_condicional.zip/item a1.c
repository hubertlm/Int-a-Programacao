#include<stdio.h>
#include<math.h>

int main ()
{
    float num1, num2, res;
    int opc;
    
    
    printf("Digite dois numeros:");
    scanf("%f %f",&num1,&num2);
    
    printf("\nEscolha uma dentre as quatro opcoes seguintes:");
    printf("\n1: Media entre os numeros digitados:");
    printf("\n2: Diferenca do maior pelo menor:");
    printf("\n3: Produto entre os numeros digitados:");
    printf("\n4: Divisao do primeiro pelo segundo:");
    printf("\nDigite a opcao escolhida:");
    scanf("\n%d",&opc);
    
    switch (opc)
    {
        case 1:
          res = (num1 + num2)/2;
          printf("\nO resultado a operacao foi:%f",res);
        
          break;
        
        case 2:
          if(num1 > num2)
          {
           res = num1-num2;
           printf("\nO resultado a operacao foi:%f",res);
           return 0;
          }
          else
          {
            res = num2 - num1;
            printf("\nO resultado a operacao foi:%f",res);
            return 0;
          }
          break;
        
        case 3:
          res = num1 * num2;
          printf("\nO resultado a operacao foi:%f",res);
         
          break;
        
        case 4:
         if(num2 != 0)
         {
            res = num1 / num2;
            printf("\nO resultado a operacao foi:%f",res);
            return 0;
         }
         else
         {
            printf("\nError!");
            return 0;
         }
         break;

        default:
        printf("\nError!");
        
    }



    return 0;
}