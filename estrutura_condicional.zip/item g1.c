#include<stdio.h>
#include<math.h>
int main ()
{
    int age;
    printf("Digite a sua idade:");
    scanf("%d",&age);

    if(age < 5)
    {
        printf("Error!");
        return 0;
    }

    else if(age <= 7)
    {
        printf("\nSua categoria eh Infantil");
        return 0;
    }
    else if(age <=10)
    {
        printf("\nSua categoria eh Ifanto-Juvenil");
        return 0;
    }
    else if(age <= 15)
    {
        printf("\nSua categoria eh Juvenil");
        return 0;
    }
    else if(age <= 30)
    {
        printf("\\nSua categoria eh Adulto");
        return 0;
    }
    else 
    {
        printf("\nSua categoria eh Master");
        return 0;
    }

    return 0;
}