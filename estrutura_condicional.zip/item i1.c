#include<stdio.h>
#include<math.h>
int main()
{
    float A, B, C;
    printf("Digite os coeficientes A, B e C da equacao:");
    scanf("%f %f %f",&A,&B,&C);
    
    float r1, r2;
    r1 = (0-B + sqrt(pow(B, 2) - 4*A*C))/2*A;
    r2 = (0-B - sqrt(pow(B, 2) - 4*A*C))/2*A;
    
    printf("As raizes da sua equacao sao:%f %f",r1, r2);


    return 0;
}