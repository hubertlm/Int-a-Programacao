#include<stdio.h>
#include<math.h>
int main()
{
    float alt, pi;
    int opc;
    printf("Digite a sua altura em metros:");
    scanf("%f",&alt);

    printf("\nDigite 1 se fores do sexo masculino ou 2 se fores do sexo feminino");
    scanf("%d",&opc);

    switch(opc)
    {
        case 1:
            pi = (72.7*alt)-58;
            printf("Seu peso ideal em quilogramas eh:%.2f",pi);
            break;
        case 2:
            pi = (62.1*alt)-44.7;
            printf("Seu peso ideal em quilogramas eh:%.2f",pi); 
            break;

        default:
            printf("Error!");    
    }
    
    return 0;
}