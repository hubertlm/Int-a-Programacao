#include<stdio.h>
#include<math.h>
int main()
{
    float sal, cred;
    printf("Digite o valor do seu saldo medio:");
    scanf("%f",&sal);
    
    if(sal <= 200)
    {
        cred = 0.1*sal;
        printf("\nPara o saldo medio %f, o credito especial tera valor de:%.2f",sal, cred);
        return 0;
    }
    
    else if(sal <=300)
    {
        cred = 0.2*sal;
        printf("\nPara o saldo medio %f, o credito especial tera valor de:%.2f",sal, cred);
        return 0;
    }
    
    else if(sal <= 400)
    {
        cred = 0.25*sal;
        printf("\nPara o saldo medio %f, o credito especial tera valor de:%.2f",sal, cred);
        return 0;     
    }
    
    else
    {
        cred = 0.3*sal;
        printf("\nPara o saldo medio %f, o credito especial tera valor de:%.2f",sal, cred);
        return 0;

    }
    return 0;
}