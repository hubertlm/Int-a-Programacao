#include<stdio.h>
#include<math.h>
int main()
{
    int x, y;
    printf("Digite dois numeros:");
    scanf("%d %d",&x,&y);
    if(x == (x/y)*y)
    {
        printf("%d eh divisivel por %d",x,y);
        return 0;
    }
    else
    {
        printf("%d nao eh divisivel por %d",x, y);
        return 0;
    }


    return 0;
}