#include<stdio.h>
#include<math.h>
int main()
{
    float sal, rea;
    printf("Digite o valor do seu salario:");
    scanf("%f",&sal);

    if(sal > 900)
    {
        printf("\nVoce nao tem direito ao aumento");

        return 0;
    }
    
    else
    {
        rea = sal*1.3;
        printf("\nO valor do seu salario reajustado sera:%.2f",rea);
 
        return 0;
    }
    return 0;
}