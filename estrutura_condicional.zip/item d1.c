#include<stdio.h>
#include<math.h>
int main()
{
    float pi, pf;
    printf("Digite o valor do produto:");
    scanf("%f",&pi);
    
    if(pi <= 50)
    {
        pf = 1.05*pi;
        printf("\nO novo valor do seu produto eh:%.2f",pf);
        printf("\nA classificacao do seu produto eh D");
        return 0;
    }

    else if(pi <= 100)
    {
        pf = 1.1*pi;
        printf("\nO novo valor do seu produto eh:%.2f",pf);
        printf("\nA classificacao do seu produto eh C");
        

        return 0;
    }

    else
    {
        pf = 1.15*pi;
        printf("\nO novo valor do seu produto eh:%.2f",pf);
        if(pf <= 120)
        {
            printf("\nA classificacao do seu produto eh C");
            return 0;
        }
        else if(pf <= 200)
        {
            printf("\nA classificacao do seu produto eh D");
            return 0;
        }
        else
        {
            printf("\nA classificacao do seu produto eh A");
            return 0;
        }
        
        return 0;
    }
    
    
    return 0;
}