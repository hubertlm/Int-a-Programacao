#include<stdio.h>
#include<math.h>
int main()
{
    float inv, cor;
    int opc;

    printf("Digite o valor a ser investido:");
    scanf("%f",&inv);

    printf("\nEscolha uma dentre as seguintes opcoes:\n1: Poupanca\n2: Fundo de renda fixa");
    printf("\nDigite a opcao escolhida:");
    scanf("%d",&opc);

    switch(opc)
    {
        case 1:
            cor = 1.1*inv;
            printf("O valor do investimento corrigido apos um mes eh:%.2f",cor);
            break;

        case 2:
            cor = 1.15*inv;
            printf("O valor do investimento corrigido apos um mes eh:%.2f",cor);
            break;

        default:
            printf("Error!");    
            break;


    }
    return 0;    
}