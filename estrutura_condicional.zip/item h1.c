#include<stdio.h>
#include<math.h>
int main()
{
    int age;
    float weight;
    printf("Digite a sua idade e o seu peso:");
    scanf("%d %f",&age,&weight);

    if(age <= 20)
    {
        if(weight <= 60)
        {
            printf("Seu grupo de risco eh 9");
            return 0;
        }
        else if(weight <= 90)
        {
            printf("Seu grupo de risco eh 8");
            return 0;
        }
        else
        {
            printf("Seu grupo de risco eh 7");
            return 0;
        }
        return 0;
    }
    else if(age <=50)
    {
        if(weight <= 60)
        {
            printf("Seu grupo de risco eh 6");
            return 0;
        }
        else if(weight <= 90)
        {
            printf("Seu grupo de risco eh 5");
            return 0;
        }
        else 
        {
            printf("Seu grupo de risco eh 4");
            return 0;
        }
        return 0;
    }
    else
    {
        if(weight <= 60)
        {
            printf("Seu grupo de risco eh 3");
            return 0;
        }
        else if(weight <= 90)
        {
            printf("Seu grupo de risco eh 2");
            return 0;
        }
        else
        {
            printf("Seu grupo de risco eh 1");
            return 0;
        }
        return 0;
    }

    return 0;
}