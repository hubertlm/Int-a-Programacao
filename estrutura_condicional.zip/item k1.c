#include<stdio.h>
#include<math.h>
int main()
{
    int x;
    printf("Digite um numero:");
    scanf("%d",&x);
    if(x == (x/5)*5)
    {
        printf("%d eh divisivel por 5",x);
        return 0;
    }
    else
    {
        printf("%d nao eh divisivel por 5",x);
        return 0;
    }


    return 0;
}