#include<stdio.h>
#include<math.h>
int main()
{
    float A, B, C;
    printf("Digite tres numeros:");
    scanf("%f %f %f",&A,&B,&C);

    if((A + B) > C > abs(A-B)&&(A+C) > B > abs(A-C)&&(B+C) > A > abs(B-C))
    {
        printf("Os tres valores configuram os lados de um triangulo");
        return 0;
    }
    else
    {
        printf("Os tres valores apresentados nao configuram os lados de um triangulo");
        return 0;
    }


    return 0;
}