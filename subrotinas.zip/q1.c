#include<stdio.h>

    void binario(int n)
    {
        int v[9];
        for(int i=0;i<9;i++)
        {
            v[i]=0;
        }
        for(int i=0;i<9;i++)
        {
            if((n%2)==0)
            {
                v[i]=0;
                n=n/2;
            }
            else
            {
                v[i]=1;
                n=n/2;
            }
        }
        for(int i=0;i<9;i++)
        {
            printf("%d",v[8-i]);
        }
        
    }

    int main()
    {
        int n;
        printf("Digite um numero n: ");
        scanf("%d",&n);
        printf("Seu numero em base binaria: ");
        binario(n);
        
        return 0;
    }