#include<stdio.h>

    int soma(int a,int b)
    {
        for(int i=0;i<b;i++)
        {
            a++;
        }
        return a;
    }
    
    int main()
    {
        int n1,n2;
        printf("Digite dois numeros naturais: ");
        scanf("%d %d",&n1,&n2);
        printf("A soma desses numeros eh: %d",soma(n1,n2));
    
        return 0;
    }