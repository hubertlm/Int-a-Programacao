#include<stdio.h>
#include<string.h>
#include<stdbool.h>

void inverte(char X[],char N[])
{
    int j = strlen(X);
    int aux = strlen(X);
    for(int i=0;i<(aux);i++)
    {
        N[i]=X[j];
        j--;
    }
}

void palindromo (char N[],char X[])
{
    bool continua=true;
    int contador=0;
    int x= strlen(X);
    while(continua) 
    {
        for(int i=0;i<x;i++)
        {
            if(N[i]!=X[i])
                continua=false;
            else
                contador++;
            if(contador==x)
                continua=false;
        }
    }
    if(contador==x)
        printf(" eh um palindromo");
    else
        printf(" nao eh um palindromo");
}


int main()
{
    char X[100];
    printf("Digite a palavra: ");
    gets(X);
    char N[strlen(X)];
    inverte(X,N);
    printf("A palavra %s",X);
    palindromo(N,X);
    return 0;
}