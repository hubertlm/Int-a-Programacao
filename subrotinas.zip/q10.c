#include<stdio.h>
//o código considera o número 0 como o primeiro numero inteiro.
int inteiros(int n)
{
    int a=0;
    for(int i=0;i<n;i++)
    {
        a=(i+1);
    }
    return a;
}

int soma(int n)
{
    int soma=0;
    for(int i=0;i<n;i++)
    {
        soma+=inteiros(i);
    }
    return soma;
}

int main()
{
    int n;
    printf("Digite um numero 'n' que vai corresponder aos n primeiros numeros inteiros a serem somados: ");
    scanf("%d",&n);
    printf("A soma dos %d primeiros numeros inteiros: %d",n,soma(n));
    return 0;
}