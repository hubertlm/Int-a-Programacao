#include<stdio.h>

float maior(float N[],int n)
{
    float maior=0;
    for(int i=0;i<n;i++)
    {
       if(N[i]>maior)
        maior = N[i];
    }
    return maior;
}
int main()
{
    int n;
    printf("Digite a quantidade de elementos que o seu vetor de numeros reais ira conter: ");
    scanf("%d",&n);
    float N[n];
    for(int i=0;i<n;i++)
    {
        printf("Digite o elemento da posicao %d do seu vetor: ",(i+1));
        scanf("%f",&N[i]);
    }
    printf("A maior elemento do seu vetor eh:: %.2f",maior(N,n));

    return 0;
}