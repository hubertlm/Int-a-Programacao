#include<stdio.h>
    int produto(int a,int b)
    {
        int prod=0;
        for(int i=0;i<a;i++)
        {
            for(int j=0;j<b;j++)
            {
                prod++;
            }
        }
        return prod;
    }

    int main()
    {
        int n1,n2;
        printf("Digite dois numeros naturais: ");
        scanf("%d %d",&n1,&n2);
        printf("O produto dos dois numeros: %d",produto(n1,n2));

        return 0;
    }