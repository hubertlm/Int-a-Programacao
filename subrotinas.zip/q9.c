#include<stdio.h>
void fibonacci(int n)
{
    int a=0,b=1,c=0;
    for(int i=0;i<n;i++)
    {
            if(i==0)
                printf("%d ",b);

            else{
            c=a+b;
            a=b;
            b=c;
            printf("%d ",c);
            }           
    }
}

int main()
{
    int n;
    printf("Digite o numero de elementos da sequencia fibonacci que deseja encontrar: ");
    scanf("%d",&n);
    printf("A sequencia ate %d: ",n);
    fibonacci(n);
    return 0;
}