#include<stdio.h>

    int produto(int a,int b)
    {
        int prod=0,aux;
        if(b<0)
            aux=0-b;
        else 
        aux=b;
        for(int i=0;i<(aux);i++)
        {
            prod+= a;
        }
        if(b<0)
        {
            prod=0-prod;
        }
        return prod;
    }   
    int main()
    {
        int n1,n2;
        printf("Digite dois numeros inteiros: ");
        scanf("%d %d",&n1,&n2);
        printf("O produto dos dois numeros: %d ", produto(n1,n2));

        return 0;
    }