#include<stdio.h>

float soma(float N[],int n)
{
    float s=0;
    for(int i=0;i<n;i++)
    {
        s+=N[i];
    }
    return s;
}
int main()
{
    int n;
    printf("Digite a quantidade de elementos que o seu vetor de numeros reais ira conter: ");
    scanf("%d",&n);
    float N[n];
    for(int i=0;i<n;i++)
    {
        printf("Digite o elemento da posicao %d do seu vetor: ",(i+1));
        scanf("%f",&N[i]);
    }
    printf("A soma dos elementos do seu vetor: %.2f",soma(N,n));

    return 0;
}