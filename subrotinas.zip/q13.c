#include<stdio.h>

void inverte(int N[],int n)
{
    int i=0,aux=0;
    int j=n;
    for(i=0;i<(n/2);i++)
    {
        aux=N[i];
        N[i]=N[j-1];
        N[j-1]=aux;
        j--;
    }
}
int main()
{
    int n;
    printf("Digite a quantidade de elementos que o seu vetor ira conter: ");
    scanf("%d",&n); 
    int N[n];
    for(int i=0;i<n;i++)
    {
        printf("Digite o elemnto de numero %d: ",(i+1));
        scanf("%d",&N[i]);
    }   
    inverte(N,n);
    printf("Seu vetor invertido: ");
    for(int i=0;i<n;i++)
    {
        printf("%d",N[i]);
    }
    return 0;
}