#include<stdio.h>
int fibonacci(int n)
{
    int a=0,b=1,c=0;
  
        if(n<=1)
            return b;
        else{
           for(int i=0;i<n;i++)
            {
                c=a+b;
                a=b;
                b=c;
            }
        }
            return c;
        }
        
int main()
{
    int n;
    printf("Digite o numero da sequencia fibonacci que deseja encontrar: ");
    scanf("%d",&n);
    printf("O numero que voce queria encontrar:%d",fibonacci(n));
    return 0;
}
