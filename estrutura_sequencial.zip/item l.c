#include<stdio.h>
#include<math.h>

int main()
{
    float sal, ht, he;
    sal = 1302;
    printf("Digite o numero de horas trabalhadas:");
    scanf("%f",&ht);
    printf("Digite o numero de horas extras:");
    scanf("%f",&he);
    printf("O salario a ser recebido tera valor de:%.2f",((sal/8)*ht)+((sal/4)*he));
 


    return 0;
}

//Em portugol:
//ALGORITMO


//	DECLARE sal, ht, he NUMERICO

//	sal <- 1302

//	ESCREVA "Digite o numero de horas trabalhadas:"
//	LEIA ht

//	ESCREVA "Digite o numero de horas extras:"
//	LEIA he

//	ESCREVA "O salario a ser recebido tera valor de:%.2f",((sal/8)*ht)+((sal/4)*he)


//FIM_ALGORITMO.