#include<stdio.h>
#include<math.h>

int main()
{ 
    float cel, fahr;
    printf("Digite a temperatura em graus celsius:");
    scanf("%f",&cel);
    fahr = (cel*1.8)+32;
    printf("A temperatura em Fahrenheit eh:%.2f",fahr);





    return 0;
}

//Em portugol:
//ALGORITMO


//	DECLARE cel, fahr NUMERICO

//	ESCREVA "Digite a temperatura em graus celsius:"
//	LEIA cel

//	fahr <- (cel*1.8)+32

//	ESCREVA "A temperatura em Fahrenheit eh:%.2f",fahr


//FIM_ALGORITMO.