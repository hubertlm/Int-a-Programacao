#include<stdio.h>
#include<math.h>
int main()
{
   float bmenor, bmaior,altura, area;
   printf("Qual eh o valor da base menor?");
   scanf("%f,",&bmenor);
   printf("Qual eh o valor da base maior?");
   scanf("%f,",&bmaior);
   printf("Qual eh o valor da altura?");
   scanf("%f,",&altura);
   area = ((bmaior+bmaior)*altura)/2;
   printf("A area do seu trapezio eh:%.2f",area);
   






    return 0;
}

//Em portugol:
//ALGORITMO


//	DECLARE bmenor, bmaior,altura, area NUMERICO

//	ESCREVA "Qual eh o valor da base menor?"
//	LEIA ", bmenor

//	ESCREVA "Qual eh o valor da base maior?"
//	LEIA ", bmaior

//	ESCREVA "Qual eh o valor da altura?"
//	LEIA ", altura

//	area <- ((bmaior+bmaior)*altura)/2

//	ESCREVA "A area do seu trapezio eh:%.2f",area


//FIM_ALGORITMO.