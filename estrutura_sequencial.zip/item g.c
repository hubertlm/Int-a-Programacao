#include<stdio.h>
#include<math.h>
int main()
{
    float min, sal, qnt;
    min = 1302;
    printf("Digite o valor do salario deste funcionario:R$");
    scanf("%f",&sal);
    qnt = sal/min;
    printf("Este funcionario recebe %.2f",qnt);
    printf(" salarios minimos");

    return 0;

}

//Em portugol:
//ALGORITMO


//	DECLARE min, sal, qnt NUMERICO

//	min <- 1302

//	ESCREVA "Digite o valor do salario deste funcionario:R$"
//	LEIA sal

//	qnt <- sal/min

//	ESCREVA "Este funcionario recebe %.2f",qnt
//	ESCREVA " salarios minimos"


//FIM_ALGORITMO.