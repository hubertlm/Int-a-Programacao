#include<stdio.h>
#include<math.h>
int main()
{
  float quilo, grama;
  
  printf("Qual eh o seu peso em quilos?");
  scanf("%f",&quilo);
  grama = quilo*1000;
  printf("Seu peso em gramas:");
  printf("%.2f",grama);






  return 0;
}

//Em portugol:
//ALGORITMO


//	DECLARE quilo, grama NUMERICO

//	ESCREVA "Qual eh o seu peso em quilos?"
//	LEIA quilo

//	grama <- quilo*1000

//	ESCREVA "Seu peso em gramas:"
//	ESCREVA "%.2f",grama


//FIM_ALGORITMO.