#include<stdio.h>
#include<math.h>

int main ()
{
    float larg, comp;
    printf("Digite o valor da largura do seu comodo em metros:");
    scanf("%f",&larg);
    printf("Digite o valor do comprimento do seu comodo em metros:");
    scanf("%f",&comp);
    printf("A area do seu comodo eh: %.2f",larg*comp);
    printf(" metros quadrados");
    printf("\nA potencia de iluminacao que deve ser utilizada para o seu comodo em watts eh: %.2f",(larg*comp)*18);


    return 0;
}

//Em portugol:
//ALGORITMO


//	DECLARE larg, comp NUMERICO

//	ESCREVA "Digite o valor da largura do seu comodo em metros:"
//	LEIA larg

//	ESCREVA "Digite o valor do comprimento do seu comodo em metros:"
//	LEIA comp

//	ESCREVA "A area do seu comodo eh: %.2f",larg*comp
//	ESCREVA " metros quadrados"
//	ESCREVA "\nA potencia de iluminacao que deve ser utilizada para o seu comodo em watts eh: %.2f",(larg*comp)*18


//FIM_ALGORITMO.