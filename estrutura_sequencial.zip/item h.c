#include<stdio.h>
#include<math.h>

int main()
{

int num;
printf("Digite um numero de 1 a 9:");
scanf("%d",&num);
printf("\n%d \n%d \n%d \n%d \n%d \n%d \n%d \n%d \n%d",num*1, num*2, num*3, num*4, num*5, num*6, num*7, num*8, num*9);







return 0;
}

//Em portugol:
//ALGORITMO


//	DECLARE num NUMERICO
//
//	ESCREVA "Digite um numero de 1 a 9:"
//	LEIA num

//	ESCREVA "\n \n%d \n%d \n%d \n%d \n%d \n%d \n%d \n%d",num*1, num*2, num*3, num*4, num*5, num*6, num*7, num*8, num*9


//FIM_ALGORITMO.