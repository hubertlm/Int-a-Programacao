#include<stdio.h>
#include<math.h>

int main() 
{
    float din;
    printf("Digite a quantidade de dinheiro que voce possui:R$");
    scanf("%f",&din);
    printf("O seu dinheiro convertido em dolares: %.2f",din/3.95);
    printf("\nO seu dinheiro convertido em marcos alemaes: %.2f",din/4.25);
    printf("\nO seu dinhero convertido em libras esterlinas: %.2f",din/5.80);

    return 0;
}

//Em portugol:
//ALGORITMO


//	DECLARE din NUMERICO

//	ESCREVA "Digite a quantidade de dinheiro que voce possui:R$"
//	LEIA din

//	ESCREVA "O seu dinheiro convertido em dolares: %.2f",din/3.95
//	ESCREVA "\nO seu dinheiro convertido em marcos alemaes: %.2f",din/4.25
//	ESCREVA "\nO seu dinhero convertido em libras esterlinas: %.2f",din/5.80


//FIM_ALGORITMO.