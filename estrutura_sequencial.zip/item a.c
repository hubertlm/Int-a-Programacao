#include<stdio.h>
#include<math.h>

int main() 
{
   float n1, n2, final;
   printf("Escreva a sua primeira nota:");
   scanf("%f",&n1);
   printf("Escreva a sua segunda nota:");
   scanf("%f",&n2);
  
   final = (n1*2+n2*3)/5;
   printf("Sua nota final foi:%.2f",final);

   return 0;
}
//algoritimo em portugol:
//ALGORITMO


	//DECLARE n1, n2, final NUMERICO

	//ESCREVA "Escreva a sua primeira nota:"
	//LEIA n1

	//ESCREVA "Escreva a sua segunda nota:"
	//LEIA n2

	//final <- (n1*2+n2*3)/5

	//ESCREVA "Sua nota final foi:%.2f",final


//FIM_ALGORITMO.