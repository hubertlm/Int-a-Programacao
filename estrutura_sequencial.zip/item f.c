#include<stdio.h>
#include<math.h>
#include<locale.h>

int main()
{

float lado, area;
printf("Digite o valor do lado do seu quadrado:");
scanf("%f",&lado);
area = lado*lado;
printf("O valor da área do seu quadrado eh:%.2f",area);



return 0;
}

//Em portugool:
//ALGORITMO


//	DECLARE lado, area NUMERICO

//	ESCREVA "Digite o valor do lado do seu quadrado:"
//	LEIA lado

//	area <- lado*lado

//	ESCREVA "O valor da área do seu quadrado eh:%.2f",area


//FIM_ALGORITMO.