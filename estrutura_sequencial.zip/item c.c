#include<stdio.h>
#include<math.h>

int main()
{
   float sal, venda;
   printf("Qual eh o valor do seu salario? ");
   scanf("%f",&sal);
   printf("Quanto voce fez em vendas? ");
   scanf("%f",&venda);
   printf("Seu salário final foi:");
   
   float final;
   final = sal+(0.4*venda);
   printf("%.2f",final);




    return 0;
}

//Em portugol:
//ALGORITMO


//	DECLARE sal, venda NUMERICO

//	ESCREVA "Qual eh o valor do seu salario? "
//	LEIA sal

//	ESCREVA "Quanto voce fez em vendas? "
//	LEIA venda

//	ESCREVA "Seu salário final foi:"
//	DECLARE final NUMERICO

//	final <- sal+(0.4*venda)

//	ESCREVA "%.2f",final


//FIM_ALGORITMO.