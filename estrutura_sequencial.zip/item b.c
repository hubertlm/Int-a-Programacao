#include<stdio.h>
#include<math.h>

int main()
{
   float p1, p2;
   printf("Digite o valor do produto:");
   scanf("%f",&p1);
   p2 = 0.9*p1;
   printf("O valor final do seu produto:%.2f",p2);


    return 0;
}
//Em portugol:
//ALGORITMO

//DECLARE p1, p2 NUMERICO

//ESCREVA "Digite o valor do produto:"
//LEIA p1

//p2 <- 0.9 * p1

//ESCREVA "O valor final do seu produto: ", p2

//FIM_ALGORITMO





