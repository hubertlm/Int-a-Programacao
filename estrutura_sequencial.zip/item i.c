#include<stdio.h>
#include<math.h>

int main() 
{
   int nasc;
   printf("Digite o ano de seu nascimento:");
   scanf("%d",&nasc);
   printf("Sua idade em anos eh: %d",2023-nasc);
   printf("\nSua idade em meses eh: %d",(2023-nasc)*12);
   printf("\nSua idade em dias eh: %d",(2023-nasc)*365);
   printf("\nSua idade em semanas eh: %d",(2023-nasc)*52);




    return 0;
}

//Em portugol:
//ALGORITMO


//	DECLARE nasc NUMERICO

//	ESCREVA "Digite o ano de seu nascimento:"
//	LEIA nasc

//	ESCREVA "Sua idade em anos eh: ",2023-nasc
//	ESCREVA "\nSua idade em meses eh: ",(2023-nasc)*12
//	ESCREVA "\nSua idade em dias eh: ",(2023-nasc)*365
//	ESCREVA "\nSua idade em semanas eh: ",(2023-nasc)*52


//FIM_ALGORITMO.