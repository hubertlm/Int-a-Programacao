#include<stdio.h>
int main()
{
    int x[4][4];
    for(int i=0;i<4;i++)
    {
        for(int j=0;j<4;j++)
        {
            scanf("%d",&x[i][j]);
        }
    }
     printf("Os elementos da matriz sem a coluna principal sao:");
    for(int i=0;i<4;i++)
    {
        for(int j=0;j<4;j++)
        {
            if(i!=j)
                printf(" %d",x[i][j]);
        }
    }
    
  
    return 0;
}