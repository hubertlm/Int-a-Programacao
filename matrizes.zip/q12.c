//O programa irá receber um numero N que definira a matriz A[N][N] e retornara se a matriz é anti-simetrica ou não.
#include<stdio.h>
int main()
{
    int N,i,j,contador=0;
    printf("Digite o elemento N(N<10), que definira o tamanho da sua matriz A[N][N]: ");
    scanf("%d",&N);
    int A[N][N];
    if(N<10)
    {
    printf("Digite os elementos da matriz:\n");
    for(i=0;i<N;i++)
    {
        for(j=0;j<N;j++)
        {
            printf("Insira o elemento da linha %d e coluna %d: ",(i+1),(j+1));
            scanf("%d",&A[i][j]);
        }
    }
    for(i=0;i<N;i++)
    {
        for(j=0;j<N;j++)
        {
            if(A[j][i]==-A[i][j])
            contador++;
        }
    }
    }
    else{
        printf("O numero digitado eh invalido");
    }
    if(contador==(N*N))
    {
        printf("\nA matriz eh anti-simetrica\n");
        printf("A matriz anti-simetrica eh:");
        for(i=0;i<N;i++)
        {
            printf("\n");
            for(j=0;j<N;j++)
                {
                printf("%d ",A[j][i]);
                }
    }
    }

    else
        printf("\nA matriz nao eh anti-simetrica\n");

    return 0;
}