#include<stdio.h>
int main()
{
    float x[3][3],id[3][3];
    int linha,coluna,m;
    float pivo=0;
    printf("Digite os elementos de uma matriz 3X3: ");
    for(linha=0;linha<3;linha++)
    {
        for(int coluna=0;coluna<3;coluna++)
        {
            printf("\nDigite o elemento linha %d coluna %d: ",linha+1,coluna+1);
            scanf("%d",&x[linha][coluna]);
        }
    }
    for(linha=0;linha<3;linha++)
    {
        for(coluna=0;coluna<3;coluna++)
        {
            if(linha==coluna)
                id[linha][coluna]=1;
            else
                id[linha][coluna]=0;
        }
    }
    


    return 0;
}