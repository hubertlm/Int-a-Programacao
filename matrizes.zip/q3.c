#include<stdio.h>
int main()
{
    int x[4][4];
    printf("Digite os elementos da matriz 4X4:\n");
    for(int i=0;i<4;i++)
    {
        for(int j=0;j<4;j++)
        {
            printf("Digite o elemento da linha %d e coluna %d: ",(i+1),(j+1));
            scanf("%d",&x[i][j]);
        }
    }
    printf("Os elementos da diagonal secundaria dessa matriz sao:");
    for(int i=0;i<4;i++)
    {
    printf(" %d",x[i][3-i]);
    }
    return 0;
}