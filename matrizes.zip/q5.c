#include<stdio.h>
int main()
{
    int x[4][4];
    for(int i=0;i<4;i++)
    {
        for(int j=0;j<4;j++)
        {
            scanf("%d",&x[i][j]);
        }
    }
     printf("Os elementos da matriz sem a coluna secundaria sao:");
    for(int i=0;i<4;i++)
    {
        for(int j=0;j<4;j++)
        {
            if(i==0&&j==3||i==1&&j==2||i==2&&j==1||i==3&&j==0)
            {
                x[i][j]=0;
            }
        }
    }
       for(int i=0;i<4;i++)
    {
        for(int j=0;j<4;j++)
        {
            if(x[i][j]!=0)
            {
                printf(" %d",x[i][j]);
            }
        }
    }
  
    return 0;
}