#include<stdio.h>
int main()
{
    int M[10][4],codigo,x[10],y=0,aux=0;
    printf("Preencha os elementos da matriz com os dados dos alunos: ");
    for(int i=0;i<10;i++)
    {
        for(int j=0;j<4;j++)
        {
            if(j==0)
            {
                printf("\nDigite a matricula do aluno %d: ",(i+1));
                scanf("%d",&M[i][j]);
            }
            if(j==1)
            {
                printf("\nDigite o sexo do aluno(a) %d (0 para feminino e 1 para masculino): ",(i+1));
                scanf("%d",&M[i][j]);
            }
            if(j==2)
            {
                printf("\nDigite o codigo do curso do aluno %d: ",(i+1));
                scanf("%d",&M[i][j]);
            }
            if(j==3)
            {
                printf("\nDigite o Coeficiente de rendimento do aluno %d: ",(i+1));
                scanf("%d",&M[i][j]);
            }   
        }
    }
    printf("\nDigite o codigo do curso que deve ser premiado: ");
    scanf("%d",&codigo);
    for(int i=0;i<10;i++)
    {
        if(M[i][2]==codigo)
        {
            if(M[i][1]==0)
            {
                x[y]=M[i][3];
                y++;

            }
        }
    }
    if(y==0)
    {
        printf("Nenhuma aluna foi premiada");
        return 0;
    }
    for(int i=0;i<y;i++)
    {
        if(x[i+1]>x[i])
        {
            aux=x[i];
            x[i]=x[i+1];
            x[i+1]=aux;
        }
    }
    printf("\nA(s) matricula(s) da(s) aluna(s) premiada(s): ");
    for(int i=0;i<10;i++)
    {
        if(M[i][2]==codigo)
        {
            if(M[i][1]==0)
            {
                if(M[i][3]==x[0])
                    printf("\n%d",M[i][0]);
            }
        }
    }
    return 0;
}