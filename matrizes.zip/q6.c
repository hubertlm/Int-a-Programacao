#include<stdio.h>
int main()
{
    int x[3][5],y[3];
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<5;j++)
        {
            scanf("%d",&x[i][j]);
        }
    }
    for(int i=0;i<3;i++)
    {
        y[i]=0;
    }
    int i=0;
    for(int j=0;j<5;j++)
    {
        y[i]+=x[i][j];
    }
    i++;
    for(int j=0;j<5;j++)
    {
        y[i]+=x[i][j];
    }
    i++;
    for(int j=0;j<5;j++)
    {
        y[i]+=x[i][j];
    }
    printf("A soma de cada linha da matriz: ");
    for(int h=0;h<3;h++)
    {
        printf(" %d",y[h]);
    }

    return 0;
}