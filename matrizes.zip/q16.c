//O programa deverá receber os elementos de uma matriz 3x3 e girar a matriz em 270 graus.
#include<stdio.h>
int main()
{
    int A[3][3];
    printf("Digite os elementos da matriz:\n");
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<3;j++)
        {
            printf("Insira o elemento da linha %d e coluna %d: ",(i+1),(j+1));
            scanf("%d",&A[i][j]);
        }
    }
    int aux=A[2][0];
    A[2][0]=A[0][0];
    A[0][0]=A[0][2];
    A[0][2]=A[2][2];
    A[2][2]=aux;
    aux=A[0][1];
    A[0][1]=A[1][2];
    A[1][2]=A[2][1];
    A[2][1]=A[1][0];
    A[1][0]=aux;
    printf("Apos girar 270 graus, a matriz tem a seguinte configuracao: ");
    for(int i=0;i<3;i++)
    {
        printf("\n");
        for(int j=0;j<3;j++)
        {
            printf("%d ",A[i][j]);
        }
    }
    return 0;
}