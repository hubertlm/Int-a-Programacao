#include<stdio.h>
int main()
{
    int x[6][3],maior=0,menor=0;
    for(int i=0;i<6;i++)
    {
        for(int j=0;j<3;j++)
        {
            scanf("%d",&x[i][j]);
        }
    }
    for(int i=0;i<6;i++)
    {
        for(int j=0;j<3;j++)
        {
            if(x[i][j]>maior)
            {
                maior=x[i][j];
            }
    }
    for(int i=0;i<6;i++)
    {
        for(int j=0;j<3;j++)
        {
            menor=x[0][0];
            if(x[i][j]<menor)
            {
                menor=x[i][j];
            }
        }
        }
    }
    printf("O maior numero da matriz eh: %d\nO menor numero da matriz eh: %d\n",maior,menor);


    return 0;
}