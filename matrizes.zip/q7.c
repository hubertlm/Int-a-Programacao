#include<stdio.h>
int main()
{
    int x[3][2],y[2][5],z[3][5],aux=0;
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<2;j++)
        {
            scanf("%d",&x[i][j]);
        }
    }
    for(int i=0;i<2;i++)
    {
        for(int j=0;j<5;j++)
        {
            scanf("%d",&y[i][j]);
        }
    }
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<5;j++)
        {
            z[i][j]=0;
            for(int k=0;k<2;k++)
            {
                aux+=x[i][k]*y[k][j];
            }
            z[i][j]=aux;
            aux=0;
        }
    }
    for(int i=0;i<3;i++)
    {
        printf("\n");
        for(int j=0;j<5;j++)
        {
            printf("%d ",z[i][j]);
            
        }
        
    }
    return 0;
}