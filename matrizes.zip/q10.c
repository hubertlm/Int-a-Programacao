//O programa irá receber um numero N que definira a matriz A[N][N] e retornara a matriz transposta.
#include<stdio.h>
int main()
{
    int N,i,j;
    printf("Digite o elemento N(N<10), que definira o tamanho da sua matriz A[N][N]: ");
    scanf("%d",&N);
    if(N<10)
    {
    int A[N][N];
    printf("Digite os elementos da matriz:");
    for(i=0;i<N;i++)
    {
        for(j=0;j<N;j++)
        {
            printf("Insira o elemento da linha %d e coluna %d: ",(i+1),(j+1));
            scanf("%d",&A[i][j]);
        }
    }
    printf("A matriz transposta eh:");
    for(i=0;i<N;i++)
    {
        printf("\n");
        for(j=0;j<N;j++)
        {
            printf("%d ",A[j][i]);
        }
    }
    }
    else
    printf("Numero invalido");


    return 0;
}