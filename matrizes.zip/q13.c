//O programa recebera os elementos de uma matriz 3X3 e retornará se ela é um quadrado mágico ou não.
#include<stdio.h>
int main()
{
    int A[3][3],x[8],y=0,contador=0;
    printf("Digite os elementos da matriz:\n");
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<3;j++)
        {
            printf("Digite o elemento da linha %d e da coluna %d: ",(i+1),(j+1));
            scanf("%d",&A[i][j]);
        }
    }
    for(int i=0;i<8;i++)
    {
        x[i]=0;
    }
    for(int i=0;i<3;i++)
    {
       x[y]+=A[i][i];
    }
    y++;
   for(int i=0;i<3;i++)
   {
    x[y]+=A[0][i];
    x[y+1]+=A[1][i];
    x[y+2]+=A[2][i];
   }
   y=y+3;
   for(int i=0;i<3;i++)
   {
    x[y]+=A[i][0];
    x[y+1]+=A[i][1];
    x[y+2]+=A[i][2];
   }
   y=y+3;
   for(int i=0;i<3;i++)
   {
    x[y]+=A[i][3-i];
   }
   for(int i=0;i<8;i++)
   {
    if(x[i]==x[i+1])
        contador++;
   }
   if(contador==7)
    printf("A matriz inserida eh um quadrado magico");
   else
    printf("A matriz inserida nao eh um quadrado magico");
    
    return 0;
}