/*Criar um algoritmo que carregue uma matriz 12 x 4 com os valores das vendas de
uma loja, em que cada linha represente um mês do ano, e cada coluna, uma semana do
mês. Para fins de simplificação considere que cada mês possui somente 4 semanas.
Calcule e imprima:
- Total vendido em cada mês do ano;
- Total vendido em cada semana durante todo o ano;
- Total vendido no ano.*/
#include<stdio.h>
int main()
{
    int a[12][4],b[13],c[4];
    printf("Digite os valores de venda da loja em cada semana de cada mes do ano:\n");
    for(int i=0;i<12;i++)
    {
        for(int j=0;j<4;j++)
        {
            printf("Digite os valores de venda do mes %d semana %d: ",(i+1),(j+1));
            scanf("%d",&a[i][j]);
        }
    }
    for(int i=0;i<17;i++)
    {
        b[i]=0;
    }
    for(int j=0;j<12;j++)
    {
    for(int i=0;i<4;i++)
    {
        b[j]+=a[j][i];
    }
    }
    for(int i=0;i<12;i++)
    {
        for(int j=0;j<4;j++)
        {
            b[12]+=a[i][j];
        }
    }
    for(int i=0;i<4;i++)
    {
        c[i]=0;
    }
    for(int j=0;j<4;j++)
    {
        for(int i=0;i<12;i++)
        {
            c[j]+=a[i][j];
        }
    }
    for(int i=0;i<12;i++)
    {
        printf("\nO total vendido no mes %d foi: %d",(i+1),b[i]);
    }
    for(int i=0;i<4;i++)
    {
        printf("\nO total vendido na semana %d ao longo do ano foi: %d",(i+1),c[i]);
    }
    printf("\nO total vendido ao longo do ano foi de: %d",b[12]);
    return 0;
}
